# import pandas as pd
#
# # 加载数据并检查列名
# train_df = pd.read_json('data/train.json', lines=True)
#
# # 打印列名确认是否存在 'label' 列
# print(train_df.columns)
#
# # 再打印前几行数据
# print(train_df.head())
#
#
# # 去除列名中的额外空格
# train_df.columns = train_df.columns.str.strip()
#
# # 打印列名确认
# print(train_df.columns)
#
#
# # 检查 'label' 列是否为空
# print(train_df['label'].isnull().sum())  # 打印 label 列的缺失值数量
#
# # 如果有缺失值，可以尝试删除缺失行
# train_df = train_df.dropna(subset=['label'])
#
#


import torch
print(torch.cuda.is_available())
