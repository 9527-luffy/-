import torch
from torch.utils.data import Dataset, DataLoader
from transformers import BertTokenizer, BertForSequenceClassification, AdamW
from sklearn.metrics import accuracy_score
import json
import os



class PrivacyPolicyDataset(Dataset):
    def __init__(self, file_path, tokenizer, label_list):
        self.tokenizer = tokenizer
        self.label_list = label_list
        self.texts = []
        self.labels = []

        # 读取数据
        with open(file_path, 'r', encoding='utf-8') as f:
            for line in f:
                sample = json.loads(line.strip())
                self.texts.append(sample['text'])
                # 标签转换为类别ID
                label_ids = [self.label_list.index(label) for label in sample['label']]
                self.labels.append(label_ids)

    def __len__(self):
        return len(self.texts)

    def __getitem__(self, idx):
        text = self.texts[idx]
        labels = self.labels[idx]
        encoding = self.tokenizer(text, padding='max_length', truncation=True, max_length=512, return_tensors="pt")
        input_ids = encoding['input_ids'].squeeze(0)
        attention_mask = encoding['attention_mask'].squeeze(0)
        return {
            'input_ids': input_ids,
            'attention_mask': attention_mask,
            'labels': torch.tensor(labels, dtype=torch.long)
        }



class PrivacyPolicyClassifier(torch.nn.Module):
    def __init__(self, num_labels):
        super(PrivacyPolicyClassifier, self).__init__()
        self.bert = BertForSequenceClassification.from_pretrained('bert-base-uncased', num_labels=num_labels)

    def forward(self, input_ids, attention_mask, labels=None):
        return self.bert(input_ids, attention_mask=attention_mask, labels=labels)



# 加载标签
with open('./data/label_list.txt', 'r', encoding='utf-8') as f:
    label_list = [line.strip() for line in f]

# 初始化tokenizer
tokenizer = BertTokenizer.from_pretrained('./bert-base-uncased')


# 创建训练集和验证集数据集
train_dataset = PrivacyPolicyDataset('./data/train.json', tokenizer, label_list)
valid_dataset = PrivacyPolicyDataset('./data/valid.json', tokenizer, label_list)

# 创建数据加载器
train_loader = DataLoader(train_dataset, batch_size=16, shuffle=True)
valid_loader = DataLoader(valid_dataset, batch_size=16, shuffle=False)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# 初始化模型
model = PrivacyPolicyClassifier(num_labels=len(label_list)).to(device)
optimizer = AdamW(model.parameters(), lr=2e-5)


# 训练函数
def train_epoch(model, data_loader, optimizer):
    model.train()
    total_loss = 0
    for batch in data_loader:
        input_ids = batch['input_ids'].to(device)
        attention_mask = batch['attention_mask'].to(device)
        labels = batch['labels'].to(device)

        optimizer.zero_grad()

        # 前向传播
        outputs = model(input_ids, attention_mask, labels)
        loss = outputs.loss
        total_loss += loss.item()

        # 反向传播
        loss.backward()
        optimizer.step()

    avg_loss = total_loss / len(data_loader)
    return avg_loss


# 验证函数
def evaluate(model, data_loader):
    model.eval()
    predictions, true_labels = [], []
    with torch.no_grad():
        for batch in data_loader:
            input_ids = batch['input_ids'].to(device)
            attention_mask = batch['attention_mask'].to(device)
            labels = batch['labels'].to(device)

            outputs = model(input_ids, attention_mask, labels=None)
            logits = outputs.logits

            # 获取预测标签
            preds = torch.argmax(logits, dim=1)
            predictions.extend(preds.cpu().numpy())
            true_labels.extend(labels.cpu().numpy())

    accuracy = accuracy_score(true_labels, predictions)
    return accuracy


# 读取测试集并预测
test_texts = []
with open('./data/test.txt', 'r', encoding='utf-8') as f:
    test_texts = [line.strip() for line in f]


# 创建测试集数据
class TestDataset(Dataset):
    def __init__(self, texts, tokenizer):
        self.texts = texts
        self.tokenizer = tokenizer

    def __len__(self):
        return len(self.texts)

    def __getitem__(self, idx):
        text = self.texts[idx]
        encoding = self.tokenizer(text, padding='max_length', truncation=True, max_length=512, return_tensors="pt")
        input_ids = encoding['input_ids'].squeeze(0)
        attention_mask = encoding['attention_mask'].squeeze(0)
        return {
            'input_ids': input_ids,
            'attention_mask': attention_mask
        }


# 加载数据
test_dataset = TestDataset(test_texts, tokenizer)
test_loader = DataLoader(test_dataset, batch_size=16, shuffle=False)

# 进行预测
model.eval()
predictions = []
with torch.no_grad():
    for batch in test_loader:
        input_ids = batch['input_ids'].to(device)
        attention_mask = batch['attention_mask'].to(device)

        outputs = model(input_ids, attention_mask, labels=None)
        logits = outputs.logits
        preds = torch.argmax(logits, dim=1)
        predictions.extend(preds.cpu().numpy())

# 将预测结果保存到文件
with open('predict.txt', 'w', encoding='utf-8') as f:
    for pred in predictions:
        f.write(f"{label_list[pred]}\n")
